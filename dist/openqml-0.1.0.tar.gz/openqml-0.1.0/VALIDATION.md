# 已完成的验证

日期：2026-10-12（Asia/Shanghai）。版本：0.1.0。

## 本地数值与接口检查

- Python 3.12.14 / NumPy 2.3.5 / Qiskit 2.5.2：`python -m pytest -q`，**103 passed**。
- 独立虚拟环境，安装正式 wheel，Python 3.12 / NumPy 1.26.4：在源码目录之外执行测试，
  **102 passed, 1 skipped**；唯一跳过项是该环境未安装的可选 Qiskit 适配器。
- `ruff check` 与 `ruff format --check` 通过。
- wheel 与源码分发包构建成功；核对依赖、版本、MIT 许可证、类型标记及源码包内文档和示例。
- 在源码目录之外导入安装后的 wheel，并完成 40 比特 GHZ CLI 采样。
- 三个示例脚本均执行成功；内置分类 suite 覆盖三个数据集、三个模型、三个 seed。

参考验证包括：独立小矩阵门计算、所有三比特 Pauli 字符串、QFT 与正号 DFT、
约化态求迹、Kraus 信道与混态门、Born 测量及量子传态反馈、有限差分与逐门移位、
BCE/MSE 损失链式法则、VQE 精确基态能量、强经典傅里叶基线、可复现数据划分、
资源限制及严格 QASM 语义。

## 尚未完成的外部步骤

- GitHub 写入返回 `403: Resource not accessible by integration`；没有远程提交或 PR。
- CI 配置已写入源码，Python 3.10/3.11/3.13 和 Windows 的远程检查尚未执行。
- 未发布到 PyPI；未连接或测试量子真机。

本记录说明实际执行过的验证，不表示量子优势、生产成熟度或任意 40 比特线路均可模拟。
